# Olaf 

You've Gone Incognito :$'s team notebook for ICPC.

## Compile
``pdflatex olaf.tex``


