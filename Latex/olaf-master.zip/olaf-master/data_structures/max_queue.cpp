struct MaxQueue { // for min, change < with >.
  deque<int> d; queue<int> q;
  void push(int v){while(sz(d)&&d.back()<v)d.pop_back();d.pb(v);q.push(v);}
  void pop(){if(sz(d)&&d.front()==q.front())d.pop_front();q.pop();}
  int getMax(){return sz(d)?d.front():NEUT;}
};
